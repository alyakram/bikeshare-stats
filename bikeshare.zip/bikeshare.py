import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    '''Get valid City, Month and Day inputs from the user '''

    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    while True:
        city = input('Please Enter the City name: ')
        city = city.lower()
        if city == 'chicago' or city == 'new york' or city == 'washington':
            break
        else:
            print('\nInvalid input Please choose from Chicago , Washington or New York \n') 

    # get user input for month (all, january, february, ... , june)
    months_list = ('all', 'january', 'february', 'march',
                   'april', 'may', 'june')
    while True:
        month = input("Please enter the desired Month or enter 'all': ")
        month = month.lower()
        if month in months_list:
            break
        print('\nInvalid input please enter any month from January till June\n')

    # get user input for day of week (all, monday, tuesday, ... sunday)
    week_list = ('all', 'sunday', 'monday', 'tuesday', 'wednesday',
                 'thursday', 'friday', 'saturday')
    while True:
        day = input("Please enter the desired day or enter 'all': ")
        day = day.lower()
        if day in week_list:
            break
        print('\nInvalid input please enter week-day name\n')
    
    print('-'*40)
    return city, month, day





def load_data(city, month, day):
    '''Load data into a Pandas DataFrame with the
       arguments returned from get_filters()'''
    
    if city == 'chicago':
        df = pd.read_csv('chicago.csv')
    elif city == 'new york':
        df = pd.read_csv('new_york_city.csv')
    else:
        df = pd.read_csv('washington.csv')
    
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['End Time'] = pd.to_datetime(df['End Time'])
    df['Week Day'] = df['Start Time'].apply(lambda x: x.weekday())
    df['Month'] = df['Start Time'].dt.month
    df['Hour'] = df['Start Time'].dt.hour
    
    weekday_dict = {'monday': 0, 'tuesday': 1,
                    'wednesday': 2, 'thursday': 3,
                    'friday': 4, 'saturday': 5, 'sunday': 6}
    
    if day != 'all':
        df = df[df['Week Day'] == weekday_dict[day]]
        
    if month != 'all':    
        df = df[df['Start Time'].dt.month_name() == month.capitalize()]
    
    
    
    return df



def time_stats(df):
    """Displays statistics on the most frequent times of travel."""
   
    # month and week dictionaries
    
    month_dict = {1 : 'January', 2 : 'February', 3 : 'March',
                  4 : 'April', 5 : 'May', 6 : 'June'}
    
    weekday_dict = {0 : 'Monday' , 1 : 'Tuesday',
                    2 : 'Wednesday', 3 : 'Thursday',
                    4 : 'Friday', 5 : 'Saturday', 6 : 'Sunday'}
    
    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month by getting value from the dictionary by using it's key
    
    month_mode = df['Month'].mode()[0]
    
    print('The most common stats for travelling in the Time period given are \n ')
    print('\nMost common Month : ' + month_dict[month_mode] )

    # display the most common day of week
    
    day_mode = df['Week Day'].mode()[0]
    print('\nMost common Day : ' + weekday_dict[day_mode] )
    
    # display the most common start hour
    
    hour_mode = df['Hour'].mode()[0]
    if hour_mode < 12:
        print(f'\nMost common Hour is : {hour_mode} AM' )
    else:
        print(f'\nMost common Hour is : {hour_mode-12} PM')

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)




def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()
    # calculating modes for Start Station and End Station

    start_station_mode = df['Start Station'].mode()[0]
    start_count = (df['Start Station'] == start_station_mode).sum()
    
    end_station_mode = df['End Station'].mode()[0]
    end_count = (df['End Station'] == end_station_mode).sum()
    # create a new column Start to End
    
    df['Start to End'] = df['Start Station'] + '/' + df['End Station'] 
    
    combination_mode = df['Start to End'].mode()[0] 
    combination_count = (df['Start to End'] == combination_mode).sum()
    
    # display most commonly used start station
    
    print(f'\n Most common Start Station is : {start_station_mode}')
    print(f'\n {start_count} times')
    
    # display most commonly used end station
    
    print(f'\n Most common End Station is : {end_station_mode}')
    print(f'\n{end_count} times')
    
    # display most frequent combination of start station and end station trip
    
    print(f'\n Most frequent combination is : {combination_mode}')
    print(f'\n {combination_count} times')
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time and mean travel time
    # displaying only the minutes and seconds in the mean travel time    

    print("Total trip time \n")
    print((df['End Time'] - df['Start Time']).sum())
    
    mean_travel_time = (df['End Time'] - df['Start Time']).mean()
    print('\nMean travel time\n')
    print(f'{mean_travel_time.components.minutes} minutes and {mean_travel_time.components.seconds} seconds')

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)



def user_stats(df, city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()
    
    subscriber_count = (df['User Type'] == 'Subscriber').sum()
    customer_count = (df['User Type'] == 'Customer').sum()
    
     
    # Display counts of user types
    
    print(f'Number of subscribers : {subscriber_count}')
    print(f'\nNumber of customers : {customer_count}')
    
    # Display counts of gender

    if city != 'washington':
        female_count = (df['Gender'] == 'Female').sum()
        male_count = (df['Gender'] == 'Male').sum()
        
        print(f'\nFemale count : {female_count}\n\nMale count : {male_count}\n')

        # Display earliest, most recent, and most common year of birth      
        
        earliest_yob = int(min(df['Birth Year']))
        most_recent_yob = int(max(df['Birth Year']))
        most_common_yob = int(df['Birth Year'].mode()[0])
        
        print(f'Earliest year of birth is {earliest_yob}\n')
        print(f'Most recent year of birth is {most_recent_yob}\n')
        print(f'Most common year of birth is {most_common_yob}\n')
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def display_raw_data(df):
    '''Displays 5 rows of raw data upon request from the user
       
       args: filtered DataFrame
            
     '''
    # delete unwanted DataFrame columns
    df.drop(['Week Day', 'Month', 'Hour', 'Start to End'], inplace = True, axis = 1)

    index = 0
    while True:
        user_choice = input('\nWould you like to see the next five rows of Data?\n (y / n) \n')
        if (user_choice.lower() != 'y') and (user_choice.lower() != 'yes'):
            return
        else:
            try:
                print((df.iloc[index : (index + 5)]))
                index += 5
            except IndexError:
                print('\nNo more Data\n')
                return
        
           




def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df,city)
        display_raw_data(df)

        restart = input('\nEnter yes to restart or any other key to stop\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
