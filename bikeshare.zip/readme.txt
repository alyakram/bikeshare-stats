Source references:
https://pandas.pydata.org/pandas-docs/stable/user_guide/timedeltas.html
https://pandas.pydata.org/docs/reference/api/pandas.DatetimeIndex.weekday.html
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.any.html
https://stackoverflow.com/questions/53037698/how-can-i-find-the-most-frequent-two-column-combination-in-a-dataframe-in-python
https://www.delftstack.com/howto/python/get-hour-from-datetime-python/